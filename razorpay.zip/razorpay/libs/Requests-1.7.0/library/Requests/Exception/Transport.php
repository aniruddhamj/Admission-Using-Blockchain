<?php

class Requests_Exception_Transport extends Requests_Exception {

}
